package com.example.homework;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int TOTAL_TIME= 30;

    private ConstraintLayout clWelcome, clQuiz;

    private ProgressBar progressBar;
    private int i=0;

    private int correctNumber;
    private int answer;

    private TextView tvNumber, tvQuestion;
    private EditText edtAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();


    }
    private void initViews(){
        clWelcome = findViewById(R.id.cl_welcome);
        clQuiz = findViewById(R.id.cl_quiz);
        progressBar = findViewById(R.id.progressBar);
        tvNumber = findViewById(R.id.tv_correct_number);
        tvQuestion = findViewById(R.id.tv_question);
        edtAnswer = findViewById(R.id.editText);
        Button btnNext = findViewById(R.id.btn_next);

        //first
        tvNumber.setText(String.valueOf(correctNumber).concat(getResources().getString(R.string.number)));
        tvQuestion.setText(getRandomEquation());

        Button btnStartQuiz = findViewById(R.id.btn_start_quiz);
        btnStartQuiz.setOnClickListener(this);
        btnNext.setOnClickListener(this);
    }

    private String getRandomEquation(){
        String[] operationSet = new String[]{" + ", " - ", " / ", " * "};
        Random random = new Random();

        int leftNum = random.nextInt(100) + 1;
        int rightNum = random.nextInt(100) + 1;

        int equationRand = random.nextInt(3);
        switch(equationRand){
            case 0:
                answer = leftNum+rightNum;
                break;
            case 1:
                answer = leftNum-rightNum;
                break;
            case 2:
                answer = leftNum / rightNum;
                break;
            case 3:
                answer = leftNum * rightNum;
                break;
        }

        return String.valueOf(leftNum).concat(operationSet[equationRand]).concat(String.valueOf(rightNum)).concat(" = ???");
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.btn_start_quiz:{
                clWelcome.setVisibility(View.GONE);
                clQuiz.setVisibility(View.VISIBLE);
                progressBar.setProgress(i);
                CountDownTimer mCountDownTimer = new CountDownTimer(TOTAL_TIME * 1000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        i++;
                        progressBar.setProgress(TOTAL_TIME - i);
                    }

                    @Override
                    public void onFinish() {
                        i++;
                        progressBar.setProgress(0);

                        String stupidness = "";
                        if(correctNumber < 5){
                            stupidness = "당신은 유치원생입니다. 괜찮습니다 부정하지 마세요.";
                        }else if(correctNumber < 10){
                            stupidness = "당신은 초등학생입니다. 몸은 어른인데...";
                        }else if(correctNumber < 15){
                            stupidness = "중고딩 수준? 좀 하네요?";
                        }else{
                            stupidness = "대학 들어갈 만하네요~";
                        }
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("수고하셨습니다!")
                                .setMessage(correctNumber+"개 맞춤! " + stupidness)
                                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                       clQuiz.setVisibility(View.GONE);
                                       correctNumber=0;
                                       i=0;
                                       tvNumber.setText(String.valueOf(correctNumber).concat(getResources().getString(R.string.number)));
                                       clWelcome.setVisibility(View.VISIBLE);
                                    }
                                })
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();


                    }
                };
                mCountDownTimer.start();
                break;
            }
            case R.id.btn_next: {
                String userAnswer = edtAnswer.getText().toString();
                try {
                    if (Integer.parseInt(userAnswer) == answer) {
                        Toast.makeText(MainActivity.this, "정답 ^^", Toast.LENGTH_SHORT).show();
                        correctNumber++;
                    } else {
                        Toast.makeText(MainActivity.this, "오답 ㅠㅠ", Toast.LENGTH_SHORT).show();
                    }
                }catch(NumberFormatException e){
                    Toast.makeText(MainActivity.this, "숫자를 제대로 입력해주세요!", Toast.LENGTH_SHORT).show();
                    return;
                }
                tvNumber.setText(String.valueOf(correctNumber).concat(getResources().getString(R.string.number)));
                edtAnswer.setText("");
                tvQuestion.setText(getRandomEquation());
                break;
            }
        }
    }
}
