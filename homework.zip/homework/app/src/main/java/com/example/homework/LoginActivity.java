package com.example.homework;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "LoginActivity";
    //view 선언
    private EditText edtId, edtPassword;


    //쓰기 권한
    private static final int PERMISSION_REQUEST_CODE = 1;

    private ArrayList<Member> userInfoList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //findViewById 초기화
        initViews();



    }
    private void initViews(){
        userInfoList = new ArrayList<>();
        edtId = findViewById(R.id.edt_id);
        edtPassword = findViewById(R.id.edt_password);
        Button btnLogin = findViewById(R.id.btn_login);
        Button btnRegister = findViewById(R.id.btn_register);

        //버튼 클릭리스너
        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);
    }
    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(LoginActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    protected void onResume() {
        super.onResume();
        //쓰기 권한
        if (Build.VERSION.SDK_INT >= 23)
        {
            if (checkPermission())
            {
                readFromFile();
            } else {
                requestPermission(); // Code for permission
            }
        }

    }

    private void readFromFile(){

        String path = Environment.getExternalStorageDirectory() + File.separator  + "config";
        File folder = new File(path);
        File file = new File(folder, "config.txt");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            //혹시 중복 데이터 쌓일 수 있으니 초기화
            if(userInfoList.size()!=0){
                userInfoList.clear();
            }

            while ((line = br.readLine()) != null) {
                String[] splitedString = line.split("\\s+");
                Member temp = new Member(splitedString[0], splitedString[1], splitedString[2], splitedString[3], splitedString[4]);
                userInfoList.add(temp);
            }
            br.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void requestPermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(LoginActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            Toast.makeText(LoginActivity.this, "쓰기 권한을 허용해주세요", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(LoginActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "권한 허용됨...");
            } else {
                finish();
                Log.e(TAG, "권한 거부됨...");
            }
        }
    }
    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.btn_login: {
                    String id = edtId.getText().toString();
                    String password = edtPassword.getText().toString();
                    boolean isValid=true;
                    for(int i=0; i<userInfoList.size(); i++){
                        Member temp = userInfoList.get(i);
                        if (id.equals(temp.getId()) && password.equals(temp.getPassword())) {
                            //success
                            Toast.makeText(LoginActivity.this, "로그인 성공!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                            return;
                        }else{
                            isValid=false;
                        }
                    }
                    if(!isValid){
                        Toast.makeText(LoginActivity.this, "아이디 및 비밀번호를 확인해주세요.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                break;
            }
            case R.id.btn_register: {
                //회원가입 페이지로 넘기기
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);

                startActivity(intent);
                break;
            }
        }
    }
}
