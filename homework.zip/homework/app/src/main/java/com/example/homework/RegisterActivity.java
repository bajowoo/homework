package com.example.homework;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    //view 선언
    private LinearLayout llExtras;
    private EditText edtId, edtPassword, edtName, edtTel, edtAddress;
    private Button btnDuplicate;

    private ArrayList<Member> userInfoList;
    private boolean isTermAgreed; //default false

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //findViewById 초기화
        initViews();
        readFromFile();
    }

    private void initViews() {
        userInfoList = new ArrayList<>();
        llExtras = findViewById(R.id.ll_extras);

        edtId = findViewById(R.id.edt_id);
        edtPassword = findViewById(R.id.edt_password);
        edtName = findViewById(R.id.edt_name);
        edtTel = findViewById(R.id.edt_tel);
        edtAddress = findViewById(R.id.edt_address);

        btnDuplicate = findViewById(R.id.btn_duplicate);
        Button btnRegister = findViewById(R.id.btn_register);

        RadioButton rbTermAgree = findViewById(R.id.rb_term_agreement);

        //버튼 클릭 리스너
        btnDuplicate.setOnClickListener(this);
        btnRegister.setOnClickListener(this);

        //라디오 버튼 체크 리스너
        rbTermAgree.setOnCheckedChangeListener(this);
    }

    private boolean checkValidities() {
        if(edtPassword.getText().toString().length() == 0){
            Toast.makeText(this, "비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(edtName.getText().toString().length() == 0){
            Toast.makeText(this, "이름을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(edtTel.getText().toString().length() == 0){
            Toast.makeText(this, "전화번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(edtAddress.getText().toString().length() == 0){
            Toast.makeText(this, "주소를 입력해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isTermAgreed){
            Toast.makeText(this, "약관에 동의해주세요.", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void readFromFile(){

        String path = Environment.getExternalStorageDirectory() + File.separator  + "config";
        File folder = new File(path);
        File file = new File(folder, "config.txt");
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            //혹시 중복 데이터 쌓일 수 있으니 초기화
            if(userInfoList.size()!=0){
                userInfoList.clear();
            }

            while ((line = br.readLine()) != null) {
                String[] splitedString = line.split("\\s+");
                Member temp = new Member(splitedString[0], splitedString[1], splitedString[2], splitedString[3], splitedString[4]);
                userInfoList.add(temp);
            }
            br.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeToFile(String data) {
        String path =
                Environment.getExternalStorageDirectory() + File.separator  + "config";


        File folder = new File(path);
        if(!folder.exists()) {
            folder.mkdirs();
        }

        File file = new File(folder, "config.txt");

        try {
            if(!file.isFile()) {
                file.createNewFile();
            }
            FileWriter filewriter = new FileWriter(file, true);

            filewriter.append(data);
            filewriter.close();
            Toast.makeText(RegisterActivity.this, "회원가입 되었습니다. 가입하신 아이디와 비밀번호로 로그인해주세요.", Toast.LENGTH_SHORT).show();
            finish();

        } catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }


        @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_duplicate: {
                //중복 검사
                String id = edtId.getText().toString();
                boolean isValid=true;
                for(int i=0; i<userInfoList.size(); i++){
                    Member temp = userInfoList.get(i);
                    if(temp.getId().equals(id)){
                        Toast.makeText(RegisterActivity.this, "해당 아이디는 사용하실 수 없습니다.", Toast.LENGTH_SHORT).show();
                        isValid=false;
                        break;
                    }
                }
                if(isValid) {
                    Toast.makeText(RegisterActivity.this, "해당 아이디는 사용 가능합니다.", Toast.LENGTH_SHORT).show();
                    btnDuplicate.setVisibility(View.GONE);
                    llExtras.setVisibility(View.VISIBLE);
                }
                break;
            }
            case R.id.btn_register: {
                if (checkValidities()) {
                    //고고
                    String id = edtId.getText().toString();
                    String password = edtPassword.getText().toString();
                    String name = edtName.getText().toString();
                    String tel = edtTel.getText().toString();
                    String address = edtAddress.getText().toString();

                    //파일에 기록
                    String finalString = id + " " +
                            password + " " +
                            name + " " +
                            tel + " " +
                            address +"\n";
                    writeToFile(finalString);

                }
                break;
            }
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if(b){
            isTermAgreed=true;
        }
    }
}
